import json
import os
from flask import Flask, jsonify, request

app = Flask(__name__)
DATA_FILE = 'library_data.json'

# --- Helper Functions ---
def load_data():
    if not os.path.exists(DATA_FILE):
        return {"media": []}
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

# --- Endpoints ---

@app.route('/media', methods=['GET'])
def get_media():
    data = load_data()
    return jsonify(data['media'])

@app.route('/media/category/<category>', methods=['GET'])
def get_media_by_category(category):
    data = load_data()
    filtered = [m for m in data['media'] if m['category'].lower() == category.lower()]
    return jsonify(filtered)

@app.route('/media/search/<name>', methods=['GET'])
def search_media(name):
    data = load_data()
    found = [m for m in data['media'] if m['name'].lower() == name.lower()]
    return jsonify(found)

@app.route('/media/<int:media_id>', methods=['GET'])
def get_single_media(media_id):
    data = load_data()
    item = next((m for m in data['media'] if m.get('id') == media_id), None)
    if item:
        return jsonify(item)
    return jsonify({"error": "Not found"}), 404

@app.route('/media', methods=['POST'])
def create_media():
    data = load_data()
    new_item = request.json
    new_id = 1
    if data['media']:
        new_id = max(m.get('id', 0) for m in data['media']) + 1
    new_item['id'] = new_id
    data['media'].append(new_item)
    save_data(data)
    return jsonify(new_item), 201

@app.route('/media/<int:media_id>', methods=['DELETE'])
def delete_media(media_id):
    data = load_data()
    initial_len = len(data['media'])
    data['media'] = [m for m in data['media'] if m.get('id') != media_id]
    if len(data['media']) < initial_len:
        save_data(data)
        return jsonify({"message": "Deleted"}), 200
    return jsonify({"error": "Not found"}), 404

if __name__ == '__main__':
    app.run(debug=True, port=5000)