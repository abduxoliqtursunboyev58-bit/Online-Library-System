import tkinter as tk
from tkinter import ttk, messagebox
import requests

API_URL = "http://127.0.0.1:5000/media"

class LibraryApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Online Library System")
        self.root.geometry("900x600")

        # --- Frames ---
        self.control_frame = tk.Frame(root)
        self.control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

        self.list_frame = tk.Frame(root)
        self.list_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.detail_frame = tk.Frame(root, bd=2, relief=tk.GROOVE)
        self.detail_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)

        # --- Controls (Filter & Search) ---
        tk.Label(self.control_frame, text="Category:").pack(side=tk.LEFT, padx=5)
        self.cat_var = tk.StringVar(value="All")
        self.cat_combo = ttk.Combobox(self.control_frame, textvariable=self.cat_var, values=["All", "Book", "Film", "Magazine"])
        self.cat_combo.pack(side=tk.LEFT, padx=5)
        tk.Button(self.control_frame, text="Filter", command=self.load_media).pack(side=tk.LEFT, padx=5)

        tk.Label(self.control_frame, text="Search Name:").pack(side=tk.LEFT, padx=10)
        self.search_entry = tk.Entry(self.control_frame)
        self.search_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(self.control_frame, text="Search", command=self.search_media).pack(side=tk.LEFT, padx=5)
        
        tk.Button(self.control_frame, text="Refresh List", command=self.load_media).pack(side=tk.RIGHT, padx=5)

        # --- Treeview (List) ---
        columns = ("ID", "Name", "Author", "Date", "Category")
        self.tree = ttk.Treeview(self.list_frame, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=150)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        # --- Details / Add New ---
        tk.Label(self.detail_frame, text="Manage Media").grid(row=0, column=0, columnspan=2, pady=5)

        tk.Label(self.detail_frame, text="Name:").grid(row=1, column=0, sticky=tk.E)
        self.entry_name = tk.Entry(self.detail_frame, width=40)
        self.entry_name.grid(row=1, column=1, padx=5, pady=2)

        tk.Label(self.detail_frame, text="Author:").grid(row=2, column=0, sticky=tk.E)
        self.entry_author = tk.Entry(self.detail_frame, width=40)
        self.entry_author.grid(row=2, column=1, padx=5, pady=2)

        tk.Label(self.detail_frame, text="Date:").grid(row=3, column=0, sticky=tk.E)
        self.entry_date = tk.Entry(self.detail_frame, width=40)
        self.entry_date.grid(row=3, column=1, padx=5, pady=2)

        tk.Label(self.detail_frame, text="Category:").grid(row=4, column=0, sticky=tk.E)
        self.entry_cat = ttk.Combobox(self.detail_frame, values=["Book", "Film", "Magazine"], width=37)
        self.entry_cat.grid(row=4, column=1, padx=5, pady=2)

        btn_frame = tk.Frame(self.detail_frame)
        btn_frame.grid(row=5, column=0, columnspan=2, pady=10)
        
        tk.Button(btn_frame, text="Add New", bg="#ddffdd", command=self.add_media).pack(side=tk.LEFT, padx=10)
        tk.Button(btn_frame, text="Delete Selected", bg="#ffdddd", command=self.delete_media).pack(side=tk.LEFT, padx=10)
        tk.Button(btn_frame, text="Clear Fields", command=self.clear_fields).pack(side=tk.LEFT, padx=10)

        # Initial Load
        self.load_media()

    def clear_fields(self):
        self.entry_name.delete(0, tk.END)
        self.entry_author.delete(0, tk.END)
        self.entry_date.delete(0, tk.END)
        self.entry_cat.set('')

    def load_media(self):
        # Determine URL based on category filter
        cat = self.cat_var.get()
        if cat and cat != "All":
            url = f"{API_URL}/category/{cat}"
        else:
            url = API_URL
        
        try:
            resp = requests.get(url)
            self.populate_tree(resp.json())
        except Exception as e:
            messagebox.showerror("Error", f"Could not connect to backend: {e}")

    def search_media(self):
        name = self.search_entry.get()
        if not name:
            return
        try:
            resp = requests.get(f"{API_URL}/search/{name}")
            self.populate_tree(resp.json())
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def populate_tree(self, data):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for item in data:
            self.tree.insert("", tk.END, values=(item.get('id'), item.get('name'), item.get('author'), item.get('year'), item.get('category')))

    def on_select(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        values = self.tree.item(selected[0], 'values')
        self.clear_fields()
        self.entry_name.insert(0, values[1])
        self.entry_author.insert(0, values[2])
        self.entry_date.insert(0, values[3])
        self.entry_cat.set(values[4])

    def add_media(self):
        payload = {
            "name": self.entry_name.get(),
            "author": self.entry_author.get(),
            "year": self.entry_date.get(),
            "category": self.entry_cat.get()
        }
        if not payload["name"] or not payload["category"]:
            messagebox.showwarning("Warning", "Name and Category are required.")
            return

        try:
            requests.post(API_URL, json=payload)
            self.load_media()
            self.clear_fields()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def delete_media(self):
        selected = self.tree.selection()
        if not selected:
            return
        
        item_id = self.tree.item(selected[0], 'values')[0]
        if messagebox.askyesno("Confirm", "Delete this item?"):
            try:
                requests.delete(f"{API_URL}/{item_id}")
                self.load_media()
                self.clear_fields()
            except Exception as e:
                messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = LibraryApp(root)
    root.mainloop()